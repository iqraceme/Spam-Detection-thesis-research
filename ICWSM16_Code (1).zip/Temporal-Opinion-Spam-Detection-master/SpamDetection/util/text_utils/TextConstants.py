'''
Created on Dec 19, 2015

@author: santhosh
'''

NLTK_DATA_PATH = '/media/santhosh/Data/workspace/nltk_data'
